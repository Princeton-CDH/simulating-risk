import marimo

__generated_with = "0.14.13"
app = marimo.App(width="medium")


@app.cell
def _():
    import marimo as mo

    from simulatingrisk.hawkdovemulti.model import HawkDoveMultipleRiskModel
    from simulatingrisk.hawkdovemulti.viz import jupyterviz_params_var
    from simulatingrisk.hawkdove.viz import agent_portrayal, draw_hawkdove_agent_space

    return (
        HawkDoveMultipleRiskModel,
        agent_portrayal,
        draw_hawkdove_agent_space,
        jupyterviz_params_var,
        mo,
    )


@app.cell
def _(jupyterviz_params_var):
    jupyterviz_params_var
    return


@app.cell
def _(jupyterviz_params_var, mo):
    type_to_ui  = {
        "SliderInt": mo.ui.slider
    }

    ui_elements = {}
    controls = []

    for param, opts in jupyterviz_params_var.items():
        # doesn't curently use description

        if opts['type'] in ['SliderInt', 'SliderFloat']:
            controls.append(mo.ui.slider(start=opts['min'], stop=opts['max'], step=opts['step'], value=opts['value'], label=opts['label'], show_value=True))
        elif opts['type'] == 'Select':
            controls.append(mo.ui.dropdown(options=opts['values'], label=opts.get('label'), value=opts['value']))
        ui_elements[param] = controls[-1]

    # add buttons to start/stop
    # step_button = mo.ui.button(label="Step")
    # controls.append(step_button)
    # run_button = mo.ui.run_button(label="▶️")
    # controls.append(run_button)

    return controls, ui_elements


@app.cell
def _(mo, ui_elements):
    # FIXME: marimo doesn't know to update this
    params = mo.ui.dictionary({arg: el for arg, el in ui_elements.items()})
    params
    return (params,)


@app.cell
def _(mo):
    slid = mo.ui.slider(start=1, stop=10, step=1)

    return (slid,)


@app.cell
def _(mo, slid):

    mo.vstack([
        slid, mo.md(f"slider {slid.value}")])
    return


@app.cell
def _(mo, slid):
    params2 = mo.ui.dictionary({'slid': slid})
    params2
    return


@app.cell
def _(mo):
    refresh = mo.ui.refresh(
      label="Refresh",
      options=["1s", "5s", "10s", "30s"]
    )
    refresh
    return (refresh,)


@app.cell
def _(
    HawkDoveMultipleRiskModel,
    agent_portrayal,
    controls,
    draw_hawkdove_agent_space,
    mo,
    params,
    refresh,
):
    model = HawkDoveMultipleRiskModel(**{param: el.value for param, el in params.items()})

    class ModelController:
        step = 1


    mc = ModelController()

    current_step = mc.step

    current_step_ui = mo.md(f"Current step: {params['grid_size']}")


    agent_grid = draw_hawkdove_agent_space(model, agent_portrayal)


    def step_model(_value):
        print(f"step {_value}")
        model.running = True
        # while model.running:
        model.step()
        # redraw the grid
        agent_grid = mo.ui.altair_chart(draw_hawkdove_agent_space(model, agent_portrayal))
        # update step count
        current_step = model.schedule.steps
        print(model.schedule.steps)
        print(current_step)
        mc.step +=1



    step_button = mo.ui.run_button(label="Step", on_change=step_model)




    mo.hstack([
        # controls
        mo.vstack([*controls, current_step_ui, step_button, refresh]),
        # space and charts
        agent_grid
    ])
    return


@app.cell
def _():
    return


if __name__ == "__main__":
    app.run()
