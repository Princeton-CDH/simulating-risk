import altair as alt

from simulatingrisk.hawkdove.model import HawkDoveModel, divergent_colors_10
from simulatingrisk.hawkdovemulti.model import HawkDoveMultipleRiskModel

# use same divergent color scale across charts
color_scale_opts = {"domain": list(range(10)), "range": divergent_colors_10}


def plot_agents_by_risk(model: HawkDoveModel) -> alt.Chart | None:
    """Plot total number of agents for each risk attitude"""
    agent_df = model.datacollector.get_agent_vars_dataframe().reset_index().dropna()
    if agent_df.empty:
        return

    last_step = agent_df.Step.max()
    # plot current status / last round
    last_round = agent_df[agent_df.Step == last_step]
    # count number of agents for each status
    grouped = last_round.groupby("risk_level", as_index=False).agg(
        total=("AgentID", "count")
    )

    # bar chart to show number of agents for each risk attitude
    # configure domain to always display all statuses;
    # limit changes depending on if diagonals are included
    # (NOTE: bug in mesa 2.12, checkbox param does not propagate)
    bar_chart = (
        alt.Chart(grouped)
        .mark_bar(width=15)
        .encode(
            x=alt.X(
                "risk_level",
                title="Risk Attitude",
                axis=alt.Axis(tickCount=model.max_risk_level + 1),
                scale=alt.Scale(domain=[model.min_risk_level, model.max_risk_level]),
            ),
            y=alt.Y("total", title="Number of Agents"),
            # NOTE: could apply divergent color scheme here, but it's actually
            # distracting from the main point of this chart, which is quantitative
            # color=alt.Color("risk_level:N").scale(**color_scale_opts),
        )
        .properties(title="Number of Agents by Risk Attitude")
    )
    return bar_chart


def plot_risklevel_changes(model: HawkDoveMultipleRiskModel) -> alt.Chart | None:
    """Plot the number of agents who updated their risk attitude on
    the last adjustment round."""
    model_df = model.datacollector.get_model_vars_dataframe().reset_index()
    if model_df.empty:
        return
    # subset dataframe to only the adjustment rounds
    model_df = model_df[:: model.adjust_round_n]
    if model_df.empty:
        return
    # limit to fields we need
    model_df = model_df[["index", "num_agents_risk_changed", "sum_risk_level_changes"]]
    # rename columns before they become variable labels
    model_df.rename(
        columns={
            "num_agents_risk_changed": "agents",
            "sum_risk_level_changes": "risk attitude totals",
        },
        inplace=True,
    )
    # "melt" to flatten so we can graph as two variables in altair
    melted_df = (
        model_df.melt(id_vars=["index"])
        .dropna()
        .rename(columns={"variable": "category"})
    )

    line_chart = (
        alt.Chart(melted_df)
        .mark_line()
        .encode(
            y=alt.Y(
                "value",
                title="Number of Changes",
                scale=alt.Scale(domain=[0, model.num_agents]),
            ),
            x=alt.X("index"),
            color=alt.Color("category", title="Category"),
        )
        .properties(title="Risk Attitude Adjustments")
    )

    return line_chart


def plot_hawks_by_risk(model: HawkDoveMultipleRiskModel) -> alt.Chart | None:
    """Plot rolling mean of percent of agents in each risk attitude
    who chose hawk over last several rounds."""

    # in the first round, mesa returns a dataframe full of NAs; ignore that
    agent_df = (
        model.datacollector.get_agent_vars_dataframe()
        .reset_index()
        .dropna(subset=["AgentID"])
    )
    if agent_df.empty:
        return

    last_step = agent_df.Step.max()
    # limit to last N rounds (how many ?)
    last_n_rounds = agent_df[agent_df.Step.gt(last_step - 60)].copy()
    last_n_rounds["hawk"] = last_n_rounds.choice.apply(
        lambda x: 1 if x == "hawk" else 0
    )
    # for each step and risk attitude, get number of agents and number of hawks
    grouped = (
        last_n_rounds.groupby(["Step", "risk_level"], as_index=False)
        .agg(hawk=("hawk", "sum"), agents=("AgentID", "count"))
        .sort_values("Step")
    )
    # calculate percent hawk within each group
    grouped["percent_hawk"] = grouped.apply(lambda row: row.hawk / row.agents, axis=1)
    # now calculate rolling percent within each risk attitude
    # thanks to https://stackoverflow.com/a/53339204
    grouped["rolling_pct_hawk"] = grouped.groupby("risk_level")[
        "percent_hawk"
    ].transform(lambda x: x.rolling(15, 1).mean())

    # starting domain 0-50 so it doesn't jump / expand as much
    max_step = max(last_step or 0, 50)
    min_step = max(max_step - 50, 0)

    chart = (
        alt.Chart(grouped[grouped.Step.gt(min_step - 1)])
        .mark_line()
        .encode(
            x=alt.X("Step", scale=alt.Scale(domain=[min_step, max_step])),
            y=alt.Y(
                "rolling_pct_hawk",
                title="Percent Hawk (Rolling Average)",
                scale=alt.Scale(domain=[0, 1]),
            ),
            color=alt.Color("risk_level:N", title="Risk Attitude").scale(
                **color_scale_opts
            ),
        )
        .properties(title="Rolling Average Percent Hawk by Risk Attitude")
    )
    return chart


def plot_wealth_by_risklevel(model: HawkDoveMultipleRiskModel) -> alt.Chart | None:
    """Plot wealth distribution for each risk attitude."""
    agent_df = model.datacollector.get_agent_vars_dataframe().reset_index().dropna()
    if agent_df.empty:
        return

    last_step = agent_df.Step.max()
    # plot current status / last round
    last_round = agent_df[agent_df.Step == last_step]

    wealth_chart = (
        alt.Chart(last_round)
        .mark_boxplot(extent="min-max")
        .encode(
            alt.X(
                "risk_level",
                scale=alt.Scale(domain=[model.min_risk_level, model.max_risk_level]),
                title="Risk Attitude",
            ),
            alt.Y("points", title="Cumulative Payoff").scale(zero=False),
        )
        .properties(title="Cumulative Payoff Distribution by Risk Attitude")
    )
    return wealth_chart
