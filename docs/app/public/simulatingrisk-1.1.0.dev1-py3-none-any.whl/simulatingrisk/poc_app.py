import marimo

__generated_with = "0.14.13"
app = marimo.App(width="medium")


@app.cell
def _():
    import marimo as mo
    import polars as pl
    import altair as alt

    from simulatingrisk.hawkdovemulti.model import HawkDoveMultipleRiskModel
    return HawkDoveMultipleRiskModel, alt, mo, pl


@app.cell
def _(mo):
    run_button = mo.ui.run_button(label="▶️")
    return (run_button,)


@app.cell
def _(current_step, mo, risk_attitude_chart, run_button):
    mo.vstack([
        run_button,
        mo.md(f"step {current_step}"),
        mo.ui.altair_chart(risk_attitude_chart)
    ])
    return


@app.cell
def _(HawkDoveMultipleRiskModel):
    m = HawkDoveMultipleRiskModel(grid_size=5)

    current_step = m.schedule.steps
    return current_step, m


@app.cell
def _(m, pl, run_button):
    # mo.stop(not run_button.value)


    model_df = pl.from_pandas(m.datacollector.get_model_vars_dataframe()).with_row_index()
    start_step = m.schedule.steps
    print(f'starting at {start_step} / {m.schedule.steps}')
    stop = start_step

    while(run_button.value and m.running and m.schedule.steps <= stop):
        print(m.schedule.steps)
        m.step()
        model_df = pl.from_pandas(m.datacollector.get_model_vars_dataframe()).with_row_index()

    
    return (model_df,)


@app.cell
def _(m):
    agents_df = m.datacollector.get_agent_vars_dataframe()
    agents_df
    return


@app.cell
def _(alt, model_df):
    risk_attitude_chart = alt.Chart(model_df).mark_line().encode(
        x='index',
        y='percent_hawk'
    )
    return (risk_attitude_chart,)


if __name__ == "__main__":
    app.run()
